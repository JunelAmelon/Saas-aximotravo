"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8683],{65531:function(e,t,r){r.d(t,{Z:function(){return u}});var n=r(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),i=(...e)=>e.filter((e,t,r)=>!!e&&r.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,n.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:r=2,absoluteStrokeWidth:o,className:l="",children:u,iconNode:s,...c},d)=>(0,n.createElement)("svg",{ref:d,...a,width:t,height:t,stroke:e,strokeWidth:o?24*Number(r)/Number(t):r,className:i("lucide",l),...c},[...s.map(([e,t])=>(0,n.createElement)(e,t)),...Array.isArray(u)?u:[u]])),u=(e,t)=>{let r=(0,n.forwardRef)(({className:r,...a},u)=>(0,n.createElement)(l,{ref:u,iconNode:t,className:i(`lucide-${o(e)}`,r),...a}));return r.displayName=`${e}`,r}},62442:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},81291:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},17158:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},78063:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},23157:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("CircleCheck",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]])},63715:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},9883:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},31541:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("Upload",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"17 8 12 3 7 8",key:"t8dd8p"}],["line",{x1:"12",x2:"12",y1:"3",y2:"15",key:"widbto"}]])},25750:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},82549:function(e,t,r){r.d(t,{Z:function(){return o}});var n=r(65531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,n.Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},30622:function(e,t,r){/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=r(2265),o=Symbol.for("react.element"),i=Symbol.for("react.fragment"),a=Object.prototype.hasOwnProperty,l=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,u={key:!0,ref:!0,__self:!0,__source:!0};function s(e,t,r){var n,i={},s=null,c=null;for(n in void 0!==r&&(s=""+r),void 0!==t.key&&(s=""+t.key),void 0!==t.ref&&(c=t.ref),t)a.call(t,n)&&!u.hasOwnProperty(n)&&(i[n]=t[n]);if(e&&e.defaultProps)for(n in t=e.defaultProps)void 0===i[n]&&(i[n]=t[n]);return{$$typeof:o,type:e,key:s,ref:c,props:i,_owner:l.current}}t.Fragment=i,t.jsx=s,t.jsxs=s},57437:function(e,t,r){e.exports=r(30622)},28712:function(e,t,r){r.d(t,{Dx:function(){return er},VY:function(){return et},aV:function(){return ee},dk:function(){return en},fC:function(){return G},h_:function(){return Q},x8:function(){return eo},xz:function(){return J}});var n=r(2265),o=r(85744),i=r(42210),a=r(56989),l=r(20966),u=r(73763),s=r(79249),c=r(52759),d=r(52730),f=r(85606),p=r(9381),y=r(31244),g=r(17552),h=r(85859),m=r(67256),v=r(57437),k="Dialog",[x,w]=(0,a.b)(k),[C,_]=x(k),b=e=>{let{__scopeDialog:t,children:r,open:o,defaultOpen:i,onOpenChange:a,modal:s=!0}=e,c=n.useRef(null),d=n.useRef(null),[f=!1,p]=(0,u.T)({prop:o,defaultProp:i,onChange:a});return(0,v.jsx)(C,{scope:t,triggerRef:c,contentRef:d,contentId:(0,l.M)(),titleId:(0,l.M)(),descriptionId:(0,l.M)(),open:f,onOpenChange:p,onOpenToggle:n.useCallback(()=>p(e=>!e),[p]),modal:s,children:r})};b.displayName=k;var D="DialogTrigger",R=n.forwardRef((e,t)=>{let{__scopeDialog:r,...n}=e,a=_(D,r),l=(0,i.e)(t,a.triggerRef);return(0,v.jsx)(p.WV.button,{type:"button","aria-haspopup":"dialog","aria-expanded":a.open,"aria-controls":a.contentId,"data-state":U(a.open),...n,ref:l,onClick:(0,o.M)(e.onClick,a.onOpenToggle)})});R.displayName=D;var j="DialogPortal",[N,Z]=x(j,{forceMount:void 0}),E=e=>{let{__scopeDialog:t,forceMount:r,children:o,container:i}=e,a=_(j,t);return(0,v.jsx)(N,{scope:t,forceMount:r,children:n.Children.map(o,e=>(0,v.jsx)(f.z,{present:r||a.open,children:(0,v.jsx)(d.h,{asChild:!0,container:i,children:e})}))})};E.displayName=j;var M="DialogOverlay",O=n.forwardRef((e,t)=>{let r=Z(M,e.__scopeDialog),{forceMount:n=r.forceMount,...o}=e,i=_(M,e.__scopeDialog);return i.modal?(0,v.jsx)(f.z,{present:n||i.open,children:(0,v.jsx)(I,{...o,ref:t})}):null});O.displayName=M;var I=n.forwardRef((e,t)=>{let{__scopeDialog:r,...n}=e,o=_(M,r);return(0,v.jsx)(g.Z,{as:m.g7,allowPinchZoom:!0,shards:[o.contentRef],children:(0,v.jsx)(p.WV.div,{"data-state":U(o.open),...n,ref:t,style:{pointerEvents:"auto",...n.style}})})}),F="DialogContent",P=n.forwardRef((e,t)=>{let r=Z(F,e.__scopeDialog),{forceMount:n=r.forceMount,...o}=e,i=_(F,e.__scopeDialog);return(0,v.jsx)(f.z,{present:n||i.open,children:i.modal?(0,v.jsx)(A,{...o,ref:t}):(0,v.jsx)(W,{...o,ref:t})})});P.displayName=F;var A=n.forwardRef((e,t)=>{let r=_(F,e.__scopeDialog),a=n.useRef(null),l=(0,i.e)(t,r.contentRef,a);return n.useEffect(()=>{let e=a.current;if(e)return(0,h.Ry)(e)},[]),(0,v.jsx)($,{...e,ref:l,trapFocus:r.open,disableOutsidePointerEvents:!0,onCloseAutoFocus:(0,o.M)(e.onCloseAutoFocus,e=>{e.preventDefault(),r.triggerRef.current?.focus()}),onPointerDownOutside:(0,o.M)(e.onPointerDownOutside,e=>{let t=e.detail.originalEvent,r=0===t.button&&!0===t.ctrlKey,n=2===t.button||r;n&&e.preventDefault()}),onFocusOutside:(0,o.M)(e.onFocusOutside,e=>e.preventDefault())})}),W=n.forwardRef((e,t)=>{let r=_(F,e.__scopeDialog),o=n.useRef(!1),i=n.useRef(!1);return(0,v.jsx)($,{...e,ref:t,trapFocus:!1,disableOutsidePointerEvents:!1,onCloseAutoFocus:t=>{e.onCloseAutoFocus?.(t),t.defaultPrevented||(o.current||r.triggerRef.current?.focus(),t.preventDefault()),o.current=!1,i.current=!1},onInteractOutside:t=>{e.onInteractOutside?.(t),t.defaultPrevented||(o.current=!0,"pointerdown"!==t.detail.originalEvent.type||(i.current=!0));let n=t.target,a=r.triggerRef.current?.contains(n);a&&t.preventDefault(),"focusin"===t.detail.originalEvent.type&&i.current&&t.preventDefault()}})}),$=n.forwardRef((e,t)=>{let{__scopeDialog:r,trapFocus:o,onOpenAutoFocus:a,onCloseAutoFocus:l,...u}=e,d=_(F,r),f=n.useRef(null),p=(0,i.e)(t,f);return(0,y.EW)(),(0,v.jsxs)(v.Fragment,{children:[(0,v.jsx)(c.M,{asChild:!0,loop:!0,trapped:o,onMountAutoFocus:a,onUnmountAutoFocus:l,children:(0,v.jsx)(s.XB,{role:"dialog",id:d.contentId,"aria-describedby":d.descriptionId,"aria-labelledby":d.titleId,"data-state":U(d.open),...u,ref:p,onDismiss:()=>d.onOpenChange(!1)})}),(0,v.jsxs)(v.Fragment,{children:[(0,v.jsx)(Y,{titleId:d.titleId}),(0,v.jsx)(K,{contentRef:f,descriptionId:d.descriptionId})]})]})}),T="DialogTitle",L=n.forwardRef((e,t)=>{let{__scopeDialog:r,...n}=e,o=_(T,r);return(0,v.jsx)(p.WV.h2,{id:o.titleId,...n,ref:t})});L.displayName=T;var V="DialogDescription",z=n.forwardRef((e,t)=>{let{__scopeDialog:r,...n}=e,o=_(V,r);return(0,v.jsx)(p.WV.p,{id:o.descriptionId,...n,ref:t})});z.displayName=V;var S="DialogClose",B=n.forwardRef((e,t)=>{let{__scopeDialog:r,...n}=e,i=_(S,r);return(0,v.jsx)(p.WV.button,{type:"button",...n,ref:t,onClick:(0,o.M)(e.onClick,()=>i.onOpenChange(!1))})});function U(e){return e?"open":"closed"}B.displayName=S;var q="DialogTitleWarning",[H,X]=(0,a.k)(q,{contentName:F,titleName:T,docsSlug:"dialog"}),Y=({titleId:e})=>{let t=X(q),r=`\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;return n.useEffect(()=>{if(e){let t=document.getElementById(e);t||console.error(r)}},[r,e]),null},K=({contentRef:e,descriptionId:t})=>{let r=X("DialogDescriptionWarning"),o=`Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${r.contentName}}.`;return n.useEffect(()=>{let r=e.current?.getAttribute("aria-describedby");if(t&&r){let e=document.getElementById(t);e||console.warn(o)}},[o,e,t]),null},G=b,J=R,Q=E,ee=O,et=P,er=L,en=z,eo=B}}]);